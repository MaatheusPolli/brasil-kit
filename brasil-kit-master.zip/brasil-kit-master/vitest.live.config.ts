import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/live/**/*.live.test.ts'],
    testTimeout: 60_000,
    retry: 1,
  },
});
